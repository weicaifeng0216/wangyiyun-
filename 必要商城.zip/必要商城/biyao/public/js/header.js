$(function(){
    $.ajax({
      url:"header.html",
      type:"get",
      success:function(html){
        //console.log(html)
        $(html).replaceAll("#header");
        $(`<link rel="stylesheet" href="../css/heder.css"/>`).appendTo("head")
      }
    })
  })