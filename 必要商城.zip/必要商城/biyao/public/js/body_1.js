$(function(){
    $.ajax({
      url:"body_1.html",
      type:"get",
      success:function(html){
        //console.log(html)
        $(html).replaceAll("#body_1");
        $(`<link rel="stylesheet" href="../css/body_1.css"/>`).appendTo("body_1")
      }
    })
  })