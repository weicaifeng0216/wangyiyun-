$(function(){
    $.ajax({
      url:"fix.html",
      type:"get",
      success:function(html){
        //console.log(html)
        $(html).replaceAll("#fix");
        $(`<link rel="stylesheet" href="../css/fix.css"/>`).appendTo("fix")
      }
    })
  })