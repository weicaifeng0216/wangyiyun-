$(function(){
    $.ajax({
      url:"footer.html",
      type:"get",
      success:function(html){
        //console.log(html)
        $(html).replaceAll("#footer");
        $(`<link rel="stylesheet" href="../css/footer.css"/>`).appendTo("footer")
      }
    })
  })