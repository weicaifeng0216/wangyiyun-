$(function(){
    $.ajax({
      url:"list.html",
      type:"get",
      success:function(html){
        //console.log(html)
        $(html).replaceAll("#list");
        $(`<link rel="stylesheet" href="../css/list.css"/>`).appendTo("list")
      }
    })
  })