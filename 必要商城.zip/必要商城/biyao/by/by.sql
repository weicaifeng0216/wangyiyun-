SET NAMES UTF8;
DROP DATABASE IF EXISTS xz;
CREATE DATABASE xz CHARSET=UTF8;
USE xz;

#by.sql 数据库脚本文件
CREATE TABLE by_laptop_family(
    fid INT PRIMARY KEY 
    fname VARCHAR();
)
-- 男士备长炭控油补水面膜
