// 1:引入2个模块 express,mysql
// 2:创建连接池
// 3：创建express对象 node.js app.js
// 4:指定静态资源目录
// 5：处理跨域请求
// 6：添加session
// 9:绑定监听端口